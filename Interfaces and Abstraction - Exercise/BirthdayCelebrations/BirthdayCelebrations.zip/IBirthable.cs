﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations
{
    public interface IBirthable
    {
        string Birthday { get; }

        bool IsSameYearBorn(string year);
    }
}
